<?php

// Configuration file for api.php

$config = array(
	// These are the settings for development mode
	'development' => array(
		'db' => array(
			'host'     => 'localhost',
			'dbname'   => 'helpDB',
			'username' => 'harsh',
			'password' => 'help',
			),
		),

	// These are the settings for production mode
	'production' => array(
		'db' => array(
			'host'     => 'localhost',
			'dbname'   => 'helpDB',
			'username' => 'harsh',
			'password' => 'help',
			),
		),
	);
